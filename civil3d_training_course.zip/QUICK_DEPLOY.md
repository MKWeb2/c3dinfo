# Quick Deployment Instructions

## 🚀 3-Minute Deployment

### Option A: Vercel (Easiest - No Terminal Required)

1. **Download the deployment package:**
   - File location: `/home/ubuntu/civil3d_training_course/civil3d-course-deployment.zip`
   - Size: 652KB

2. **Go to Vercel:**
   - Visit: https://vercel.com/new
   - Sign in with GitHub, GitLab, or Bitbucket

3. **Deploy:**
   - Click "Deploy from local files" or use the import wizard
   - Upload the `civil3d-course-deployment.zip` file
   - Click "Deploy"
   - **Done!** You'll get a URL like: `https://civil3d-training.vercel.app`

---

### Option B: Netlify Drop (Drag & Drop)

1. **Extract the zip file:**
   - Unzip `civil3d-course-deployment.zip`
   - You'll see a folder called `out/`

2. **Go to Netlify:**
   - Visit: https://app.netlify.com/drop
   - Sign in if prompted

3. **Deploy:**
   - Drag the entire `out/` folder onto the page
   - **Done!** You'll get a URL like: `https://random-name-12345.netlify.app`

---

### Option C: Using Terminal Scripts

I've created automated scripts for you:

**For Vercel:**
```bash
cd /home/ubuntu/civil3d_training_course
chmod +x deploy-vercel.sh
./deploy-vercel.sh
```

**For Netlify:**
```bash
cd /home/ubuntu/civil3d_training_course
chmod +x deploy-netlify.sh
./deploy-netlify.sh
```

**To test locally first:**
```bash
cd /home/ubuntu/civil3d_training_course
chmod +x test-locally.sh
./test-locally.sh
```

---

## 📦 What's Being Deployed?

- ✅ Complete 12-session training course
- ✅ GoHighLevel integration page  
- ✅ Progress tracking system
- ✅ Responsive design (mobile-friendly)
- ✅ All images and assets
- ✅ Navigation system

**Total size:** 652KB (compressed), 3.2MB (uncompressed)

---

## 🔗 After Deployment

Once deployed, you'll receive a public URL like:
- `https://your-project.vercel.app`
- `https://your-project.netlify.app`

Use this URL for:
1. **Direct access** - Share with students
2. **GoHighLevel integration** - Embed in your funnels
3. **iFrame embedding** - Use in other platforms
4. **Custom domain** - Point your own domain to it

---

## 🎯 For GoHighLevel Integration

Once you have your public URL, follow these steps in GoHighLevel:

1. **Create a new page or funnel**
2. **Add an iFrame/Embed element**
3. **Paste your URL:**
   ```
   https://[your-deployment-url]/session/1
   ```
4. **Adjust height to 800-1000px**
5. **Save and publish**

For detailed integration methods, visit:
```
https://[your-deployment-url]/integration
```

---

## ❓ Troubleshooting

**Q: The scripts aren't working**  
A: Make sure they're executable: `chmod +x deploy-*.sh`

**Q: I don't want to use the terminal**  
A: Use Option A or B above - no terminal required!

**Q: Can I use my own domain?**  
A: Yes! Both Vercel and Netlify support custom domains in their settings.

**Q: Is this free?**  
A: Yes! Both Vercel and Netlify offer free tiers perfect for this project.

---

## 📞 Need Help?

If you encounter any issues:
1. Check that you're logged into Vercel/Netlify
2. Verify the zip file is not corrupted
3. Try the alternative deployment method
4. Contact me with the error message

---

**Ready to deploy?** Choose your preferred method above and get started! 🚀