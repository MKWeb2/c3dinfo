#!/bin/bash

# Vercel Deployment Script for Civil 3D Training Course
# This script deploys the static site to Vercel

set -e

echo "🚀 Civil 3D Training Course - Vercel Deployment"
echo "================================================"
echo ""

# Check if vercel is installed
if ! command -v vercel &> /dev/null; then
    echo "📦 Installing Vercel CLI..."
    npm install -g vercel
fi

echo "📍 Current directory: $(pwd)"
cd /home/ubuntu/civil3d_training_course/nextjs-app

echo ""
echo "🔐 Please login to Vercel when prompted..."
echo ""

npx vercel login

echo ""
echo "🚢 Deploying to Vercel..."
echo ""

npx vercel deploy --prod --yes

echo ""
echo "✅ Deployment complete!"
echo "📋 Your site URL will be displayed above"
echo ""