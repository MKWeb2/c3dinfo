# Civil 3D Training Course - Deployment Guide

## 📦 Deployment Status

The website has been **built and exported** as static files in the `/nextjs-app/out/` directory (3.2MB).

All static files are ready for deployment to any static hosting platform.

---

## 🚀 Quick Deployment Options

### Option 1: Vercel (Recommended - Easiest)

**Steps:**
1. Go to [https://vercel.com](https://vercel.com)
2. Sign up/login with your GitHub account
3. Click "Add New" → "Project"
4. Click "Browse" and upload the entire `/nextjs-app/out/` folder
5. Click "Deploy"
6. Your site will be live at `https://[your-project-name].vercel.app`

**OR via CLI:**
```bash
cd /home/ubuntu/civil3d_training_course/nextjs-app
npx vercel login
npx vercel deploy --prod
```

---

### Option 2: Netlify

**Steps:**
1. Go to [https://app.netlify.com](https://app.netlify.com)
2. Sign up/login
3. Drag and drop the `/nextjs-app/out/` folder onto the page
4. Your site will be live at `https://[random-name].netlify.app`

**OR via CLI:**
```bash
npm install -g netlify-cli
cd /home/ubuntu/civil3d_training_course/nextjs-app/out
netlify deploy --prod
```

---

### Option 3: GitHub Pages

**Steps:**
1. Create a new GitHub repository
2. Clone it locally
3. Copy the contents of `/nextjs-app/out/` to the repository
4. Commit and push:
   ```bash
   git add .
   git commit -m "Deploy Civil 3D Training Course"
   git push origin main
   ```
5. Go to repository Settings → Pages
6. Select "Deploy from branch" and choose "main"
7. Your site will be live at `https://[username].github.io/[repo-name]/`

---

### Option 4: Cloudflare Pages

**Steps:**
1. Go to [https://pages.cloudflare.com](https://pages.cloudflare.com)
2. Sign up/login
3. Click "Create a project"
4. Upload the `/nextjs-app/out/` folder
5. Your site will be live at `https://[project-name].pages.dev`

---

## 📋 Pre-Deployment Checklist

✅ Static files generated in `/nextjs-app/out/`  
✅ All 12 sessions included  
✅ Integration page ready  
✅ Navigation system functional  
✅ Progress tracking component included  
✅ Responsive design implemented  

---

## 🔗 What's Included

The exported static site includes:
- **Homepage** (`index.html`) - Course overview and session list
- **12 Session Pages** - Comprehensive training content
- **Integration Page** - GoHighLevel integration instructions
- **All Assets** - Images, styles, and JavaScript bundles
- **404 Page** - Custom error handling

---

## 🌐 Expected URL Structure

Once deployed, your URLs will follow this pattern:
```
https://[your-domain]/                    → Homepage
https://[your-domain]/session/1           → Session 1
https://[your-domain]/session/2           → Session 2
...
https://[your-domain]/session/12          → Session 12
https://[your-domain]/integration         → Integration guide
```

---

## 🔄 For GoHighLevel Integration

Once deployed, you'll use the public URL in GoHighLevel:

1. **Custom Domain**: Add your Vercel/Netlify URL as an external link
2. **iFrame Embed**: Embed specific session pages
3. **Redirect**: Set up redirects from GoHighLevel to your course
4. **API Integration**: Use webhooks to track user progress

Example iframe code:
```html
<iframe 
  src="https://[your-deployment-url]/session/1" 
  width="100%" 
  height="800px" 
  frameborder="0"
></iframe>
```

---

## 🛠️ Automated Deployment Script

I can help you deploy via command line. Here are the steps:

### For Vercel:
```bash
cd /home/ubuntu/civil3d_training_course/nextjs-app
npx vercel login
npx vercel deploy --prod --yes
```

### For Netlify:
```bash
npm install -g netlify-cli
cd /home/ubuntu/civil3d_training_course/nextjs-app/out
netlify login
netlify deploy --prod --dir=.
```

---

## 📦 Manual Deployment Package

If you want to deploy elsewhere, simply:
1. Zip the `/nextjs-app/out/` folder
2. Upload to any static hosting provider
3. Configure the root directory to serve `index.html`

**Create deployment package:**
```bash
cd /home/ubuntu/civil3d_training_course/nextjs-app
tar -czf civil3d-course-deploy.tar.gz out/
# or
zip -r civil3d-course-deploy.zip out/
```

---

## 🔍 Testing Locally

To test before deployment:
```bash
cd /home/ubuntu/civil3d_training_course/nextjs-app/out
python3 -m http.server 8000
# Visit http://localhost:8000
```

**Note:** This localhost refers to the server I'm using, not your local machine.

---

## ❓ Need Help?

If you encounter any issues during deployment:
1. Check that all files in `/nextjs-app/out/` are present
2. Verify the hosting provider supports static HTML sites
3. Ensure the root directory is set correctly
4. Check for any CORS or security policy issues

---

## 📞 Next Steps

1. Choose your preferred hosting platform from the options above
2. Follow the deployment steps for that platform
3. Get your public URL (e.g., `https://civil3d-training.vercel.app`)
4. Share that URL with me for GoHighLevel integration setup
5. I'll help you configure the integration with GoHighLevel

---

**Last Updated:** December 10, 2025  
**Build Size:** 3.2MB  
**Technology:** Next.js 14 Static Export
