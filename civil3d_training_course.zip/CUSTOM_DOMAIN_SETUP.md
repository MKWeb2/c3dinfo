# Custom Domain Setup Guide: classes.c3dinfo.com

This guide will walk you through deploying your Civil 3D Training Course website to Vercel and configuring it to work with your custom domain `classes.c3dinfo.com`.

## 📋 Overview

- **Source Directory**: `/home/ubuntu/civil3d_training_course/nextjs-app/`
- **Build Output**: `/home/ubuntu/civil3d_training_course/nextjs-app/out/` (3.2MB)
- **Target Domain**: `https://classes.c3dinfo.com`
- **Platform**: Vercel
- **SSL Certificate**: Automatically provisioned by Vercel

---

## 🚀 Part 1: Deploy to Vercel

### Option A: Deploy via Vercel CLI (Recommended)

#### Step 1: Navigate to the project directory
```bash
cd /home/ubuntu/civil3d_training_course/nextjs-app/
```

#### Step 2: Authenticate with Vercel
```bash
npx vercel login
```

This will:
- Prompt you to enter your email address
- Send a verification email to your inbox
- Click the verification link in the email to authenticate

#### Step 3: Deploy to Vercel (Production)
```bash
npx vercel --prod
```

During deployment, you'll be asked several questions:
1. **Set up and deploy?** → Press `Y` (Yes)
2. **Which scope?** → Select your Vercel account
3. **Link to existing project?** → Press `N` (No) - this is a new project
4. **Project name?** → Press Enter to accept `nextjs-app` or enter `civil3d-training-course`
5. **Directory to deploy?** → Press Enter (current directory)
6. **Override settings?** → Press `N` (No)

The deployment will:
- Upload your built files from the `out/` directory
- Generate a production URL (e.g., `https://civil3d-training-course.vercel.app`)
- Display the URL in the terminal

**🎯 Save this URL! You'll need it to verify the deployment before setting up the custom domain.**

---

### Option B: Deploy via Vercel Dashboard (Alternative)

If you prefer a visual interface:

1. **Login to Vercel**
   - Go to [https://vercel.com](https://vercel.com)
   - Sign in with your account

2. **Import Project**
   - Click "Add New..." → "Project"
   - Select "Import Git Repository" or "Continue with GitHub/GitLab/Bitbucket"
   - If not using Git, scroll down and select "Import from .vercel/output or out/ directory"

3. **Upload Build**
   - Upload the entire `out/` directory from `/home/ubuntu/civil3d_training_course/nextjs-app/out/`
   - Or connect your Git repository if the code is pushed to GitHub/GitLab

4. **Configure Project**
   - Project Name: `civil3d-training-course`
   - Framework Preset: `Next.js`
   - Output Directory: `out`
   - Click "Deploy"

5. **Wait for Deployment**
   - Vercel will process and deploy your site
   - You'll receive a production URL (e.g., `https://civil3d-training-course.vercel.app`)

---

## 🌐 Part 2: Configure Custom Domain (classes.c3dinfo.com)

Once your site is deployed to Vercel, follow these steps to add your custom domain.

### Step 1: Access Domain Settings in Vercel

1. Go to your Vercel dashboard: [https://vercel.com/dashboard](https://vercel.com/dashboard)
2. Click on your project (e.g., `civil3d-training-course`)
3. Navigate to **Settings** → **Domains**

### Step 2: Add Custom Domain

1. In the "Domains" section, you'll see an input field
2. Enter: `classes.c3dinfo.com`
3. Click **"Add"**

Vercel will check if the domain is available and provide DNS instructions.

### Step 3: Choose Domain Configuration

Vercel will ask you to confirm the domain setup. You'll see options:
- ✅ **Recommended**: Add `classes.c3dinfo.com` as a subdomain
- Select this option and click **"Add"**

---

## 🔧 Part 3: Configure DNS Records

You need to add DNS records at your domain registrar (where you purchased `c3dinfo.com`). This tells the internet to point `classes.c3dinfo.com` to your Vercel deployment.

### DNS Records to Add

#### Option 1: CNAME Record (Recommended for Subdomains)

Add the following CNAME record to your DNS provider:

| Type  | Name     | Value                  | TTL  |
|-------|----------|------------------------|------|
| CNAME | classes  | cname.vercel-dns.com   | 3600 |

**Explanation:**
- **Type**: CNAME (Canonical Name)
- **Name**: `classes` (this creates `classes.c3dinfo.com`)
- **Value**: `cname.vercel-dns.com` (Vercel's DNS endpoint)
- **TTL**: 3600 seconds (1 hour) or Auto

#### Option 2: A Record (Alternative)

If your DNS provider doesn't support CNAME records for subdomains, use A records:

| Type | Name     | Value         | TTL  |
|------|----------|---------------|------|
| A    | classes  | 76.76.21.21   | 3600 |

**Note**: Vercel will show you the exact IP address in the dashboard. Use the one provided there.

---

## 📍 Where to Add DNS Records

The steps vary depending on your domain registrar. Here are instructions for common providers:

### GoDaddy
1. Log in to [GoDaddy Domain Manager](https://dcc.godaddy.com/manage/dns)
2. Find `c3dinfo.com` and click **"DNS"**
3. Scroll to **"Records"** section
4. Click **"Add"** to create a new record
5. Enter the CNAME details above
6. Click **"Save"**

### Namecheap
1. Log in to [Namecheap Dashboard](https://www.namecheap.com/myaccount/login/)
2. Go to **"Domain List"** → Click **"Manage"** next to `c3dinfo.com`
3. Select **"Advanced DNS"** tab
4. Click **"Add New Record"**
5. Enter the CNAME details above
6. Click **"Save All Changes"**

### Cloudflare
1. Log in to [Cloudflare Dashboard](https://dash.cloudflare.com/)
2. Select `c3dinfo.com` from your domains
3. Go to **"DNS"** tab
4. Click **"Add record"**
5. Enter the CNAME details above
6. **Important**: Set Proxy status to **"DNS only"** (gray cloud, not orange)
7. Click **"Save"**

### Google Domains / Squarespace
1. Log in to [Google Domains](https://domains.google.com/registrar/)
2. Click on `c3dinfo.com`
3. Go to **"DNS"** in the left menu
4. Scroll to **"Custom resource records"**
5. Enter the CNAME details above
6. Click **"Add"**

### Other Providers
If you're using a different provider:
1. Log in to your domain registrar
2. Look for "DNS Management", "DNS Settings", or "Nameservers"
3. Add a CNAME record with the details above
4. Save your changes

---

## ⏱️ Part 4: Wait for DNS Propagation

After adding the DNS records:

1. **Initial propagation**: 5-30 minutes (typically)
2. **Full propagation**: Up to 48 hours (worst case)
3. **Average time**: 1-4 hours

During this time:
- Some people may see your site, others may not
- This is completely normal
- Be patient and wait for full propagation

---

## ✅ Part 5: Verify SSL Certificate

Vercel automatically provisions SSL certificates using Let's Encrypt. Here's how to verify:

### In Vercel Dashboard

1. Go to your project in Vercel
2. Navigate to **Settings** → **Domains**
3. Look for `classes.c3dinfo.com`
4. You should see a green checkmark and **"Valid Configuration"**
5. SSL status will show as **"Active"** or **"Provisioning"**

If the SSL certificate is still provisioning:
- Wait 5-10 minutes after DNS propagation
- Vercel will automatically detect the DNS changes
- The certificate will be issued automatically
- You'll receive an email notification when it's ready

---

## 🧪 Part 6: Verification Steps

### Step 1: Check DNS Propagation

Use online tools to verify your DNS records are working:

1. **DNS Checker**: [https://dnschecker.org/](https://dnschecker.org/)
   - Enter: `classes.c3dinfo.com`
   - Select: `CNAME` record type
   - Click **"Search"**
   - You should see `cname.vercel-dns.com` as the result

2. **Command Line** (if you have terminal access):
   ```bash
   dig classes.c3dinfo.com
   # or
   nslookup classes.c3dinfo.com
   ```
   Expected output should include `cname.vercel-dns.com`

### Step 2: Test HTTP Access

1. Open your browser
2. Go to: `http://classes.c3dinfo.com`
3. You should see your Civil 3D Training Course website
4. Note: HTTP (not HTTPS) should work immediately after DNS propagates

### Step 3: Test HTTPS Access (SSL)

1. Wait for SSL certificate to be provisioned (5-15 minutes after DNS propagation)
2. Go to: `https://classes.c3dinfo.com`
3. You should see:
   - 🔒 Padlock icon in the browser address bar
   - Your website loads without any security warnings
   - The URL shows `https://` (secure)

### Step 4: Check Certificate Details

1. In your browser, click the **🔒 padlock** icon in the address bar
2. Click **"Certificate"** or **"Connection is secure"** → **"Certificate is valid"**
3. Verify:
   - **Issued to**: `classes.c3dinfo.com`
   - **Issued by**: `Let's Encrypt` or `Vercel`
   - **Valid until**: (should be 90 days from now)

### Step 5: Test All Pages

Visit these URLs to ensure everything works:

- Homepage: `https://classes.c3dinfo.com/`
- Sessions: `https://classes.c3dinfo.com/session/1`
- Sessions: `https://classes.c3dinfo.com/session/2`
- Resources: `https://classes.c3dinfo.com/resources`

All pages should:
- Load quickly
- Display correctly
- Have HTTPS (secure connection)
- Show no mixed content warnings

---

## 🔄 Part 7: Automatic HTTPS Redirect

Vercel automatically redirects HTTP to HTTPS. To verify:

1. Visit `http://classes.c3dinfo.com` (note: HTTP, not HTTPS)
2. It should automatically redirect to `https://classes.c3dinfo.com`
3. Check the address bar - it should show `https://`

If this doesn't work:
- Go to Vercel Dashboard → Project → Settings → Domains
- Ensure "HTTPS" toggle is enabled
- Save changes

---

## 🎨 Part 8: Optional - Set Primary Domain

If you want `classes.c3dinfo.com` to be your primary domain:

1. In Vercel Dashboard, go to **Settings** → **Domains**
2. You'll see multiple domains listed:
   - `civil3d-training-course.vercel.app` (default)
   - `classes.c3dinfo.com` (custom)
3. Click the **⋮** menu next to `classes.c3dinfo.com`
4. Select **"Set as Primary Domain"**
5. This ensures all traffic redirects to your custom domain

---

## 🐛 Troubleshooting

### Issue 1: "Domain is not yet propagated"

**Symptoms:**
- Vercel shows "Invalid Configuration" for the domain
- DNS checker shows different results in different locations

**Solution:**
1. Wait 1-4 hours for full DNS propagation
2. Verify DNS records are correct at your registrar
3. Use [WhatsMyDNS.net](https://whatsmydns.net/) to check global propagation
4. Clear your browser cache and try again

---

### Issue 2: "ERR_SSL_VERSION_OR_CIPHER_MISMATCH"

**Symptoms:**
- HTTPS doesn't work
- Browser shows SSL/TLS error
- Certificate is not valid

**Solution:**
1. Wait 15-30 minutes after DNS propagation for SSL certificate
2. Go to Vercel Dashboard → Settings → Domains
3. Click "Refresh" or "Retry" next to the domain
4. If still not working, remove and re-add the domain

---

### Issue 3: "Domain is already in use"

**Symptoms:**
- Vercel says the domain is already assigned to another project
- Can't add `classes.c3dinfo.com`

**Solution:**
1. Check if you have another Vercel project using this domain
2. Go to that project and remove the domain
3. Return to your Civil 3D project and add the domain again

---

### Issue 4: DNS Records Not Saving

**Symptoms:**
- DNS records disappear after saving
- Changes don't take effect

**Solution:**
1. Check if you're modifying the correct domain (`c3dinfo.com`, not another one)
2. Some registrars require you to remove existing records before adding new ones
3. Disable any "domain parking" or "forwarding" services
4. Contact your registrar's support if the issue persists

---

### Issue 5: Site Shows "404 - This page could not be found"

**Symptoms:**
- Homepage loads but other pages show 404
- Links don't work

**Solution:**
1. Check if the build output is correct in the `out/` directory
2. Verify `vercel.json` configuration is correct
3. Ensure the deployment includes all necessary files
4. Try redeploying: `npx vercel --prod --force`

---

### Issue 6: Cloudflare Proxy Issues

**Symptoms:**
- Using Cloudflare and domain doesn't work
- SSL certificate issues with Cloudflare

**Solution:**
1. In Cloudflare DNS settings, set the CNAME record to **"DNS only"** (gray cloud)
2. Do NOT use "Proxied" (orange cloud) - this can cause conflicts
3. Wait for DNS propagation after making the change
4. Alternative: Use Cloudflare's "Full (strict)" SSL mode if you want the proxy

---

## 📊 Deployment Summary

After completing all steps, your deployment will have:

✅ **Production URL**: `https://civil3d-training-course.vercel.app` (or similar)  
✅ **Custom Domain**: `https://classes.c3dinfo.com`  
✅ **SSL Certificate**: Automatically provisioned (Let's Encrypt via Vercel)  
✅ **HTTPS Redirect**: HTTP automatically redirects to HTTPS  
✅ **Global CDN**: Content delivered via Vercel's global edge network  
✅ **Static Site**: Fast loading, no server required  
✅ **Build Size**: ~3.2MB (optimized)

---

## 🔄 Future Deployments

When you need to update the site:

### Method 1: CLI Deployment
```bash
cd /home/ubuntu/civil3d_training_course/nextjs-app/
npm run build              # Rebuild the site
npx vercel --prod          # Deploy to production
```

### Method 2: Git Integration (Recommended for frequent updates)
1. Push your code to GitHub/GitLab/Bitbucket
2. Connect the repository to Vercel
3. Enable automatic deployments
4. Every push to the main branch will automatically deploy

To set up Git integration:
```bash
cd /home/ubuntu/civil3d_training_course/
git init
git add .
git commit -m "Initial commit"
git remote add origin <your-repo-url>
git push -u origin main
```

Then in Vercel:
1. Dashboard → Add New → Import Git Repository
2. Select your repository
3. Vercel will auto-detect Next.js and configure everything
4. Future pushes will trigger automatic deployments

---

## 📞 Support Resources

- **Vercel Documentation**: [https://vercel.com/docs](https://vercel.com/docs)
- **Vercel Support**: [https://vercel.com/support](https://vercel.com/support)
- **DNS Propagation Checker**: [https://dnschecker.org](https://dnschecker.org)
- **SSL Checker**: [https://www.ssllabs.com/ssltest/](https://www.ssllabs.com/ssltest/)

---

## ✨ Next Steps After Deployment

1. **Test all features**: Go through every session, verify videos load, check navigation
2. **Monitor performance**: Use Vercel Analytics to track page views and performance
3. **Set up GoHighLevel integration**: Configure form submissions and user tracking
4. **Add Google Analytics**: Track user behavior and course completion rates
5. **Create backups**: Export your deployment settings and keep a local backup of the `out/` directory
6. **Document for your team**: Share this guide with anyone who needs to manage the deployment

---

## 📝 Quick Reference Card

**Your URLs:**
- Development: `http://localhost:3000` (local)
- Production Vercel: `https://civil3d-training-course.vercel.app` (or your assigned URL)
- Custom Domain: `https://classes.c3dinfo.com` (your branded URL)

**DNS Record:**
```
Type:  CNAME
Name:  classes
Value: cname.vercel-dns.com
TTL:   3600 (or Auto)
```

**Deploy Command:**
```bash
cd /home/ubuntu/civil3d_training_course/nextjs-app/
npx vercel --prod
```

**Rebuild Command:**
```bash
npm run build
```

---

**Last Updated**: December 10, 2025  
**Project**: Civil 3D Training Course  
**Target Domain**: classes.c3dinfo.com  
**Platform**: Vercel (Static Hosting with CDN)

---

Need help? Refer to the troubleshooting section above or consult Vercel's documentation.

**Good luck with your deployment! 🚀**
