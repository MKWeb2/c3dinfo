# 🚀 Deploy Civil 3D Training Course - Quick Start

**Target URL:** https://classes.c3dinfo.com  
**Time Required:** ~20 minutes + DNS propagation

---

## Three Simple Steps

### 1️⃣ Deploy to Vercel (5 minutes)

```bash
cd /home/ubuntu/civil3d_training_course/nextjs-app
npx vercel login
```
↳ Enter your email, click verification link in email

```bash
npx vercel --prod --yes
```
↳ Saves deployment URL (e.g., `civil3d-training-course-xxxxx.vercel.app`)

---

### 2️⃣ Add Custom Domain (1 minute)

```bash
npx vercel domains add classes.c3dinfo.com --prod
```

---

### 3️⃣ Configure DNS (5 minutes)

Go to your DNS provider where `c3dinfo.com` is registered and add:

```
Type:  A
Name:  classes
Value: 76.76.21.21
TTL:   3600
```

**Common DNS Providers:**
- **GoDaddy:** dcc.godaddy.com → Manage DNS → Add Record
- **Cloudflare:** dash.cloudflare.com → DNS → Add Record (set to "DNS only")
- **Namecheap:** Domains → Manage → Advanced DNS → Add Record

---

## ⏱️ What Happens Next

1. **5-10 min:** DNS starts propagating
2. **15-30 min:** Site becomes accessible at https://classes.c3dinfo.com
3. **1-24 hours:** SSL certificate auto-provisions (HTTPS)

---

## ✅ Verify It Worked

```bash
# Check DNS
nslookup classes.c3dinfo.com
# Should show: 76.76.21.21

# Check site
curl -I https://classes.c3dinfo.com
# Should return: HTTP/2 200
```

Or simply visit: **https://classes.c3dinfo.com** in your browser

---

## 🆘 Having Issues?

### Authentication failed
```bash
npx vercel login
```

### Domain not verified
- Wait 15-30 minutes for DNS
- Check record: `nslookup classes.c3dinfo.com`
- Verify A record shows `76.76.21.21`

### Need detailed help?
See: `/home/ubuntu/civil3d_training_course/VERCEL_DEPLOYMENT_COMPLETE.md`

---

## 🎯 Alternative: One-Click Script

Run this automated script:

```bash
cd /home/ubuntu/civil3d_training_course
./deploy-to-vercel.sh
```

Then follow DNS configuration step above.

---

## 📁 All Deployment Files

- `VERCEL_DEPLOYMENT_COMPLETE.md` - Detailed guide with troubleshooting
- `DNS_CONFIGURATION.md` - DNS setup for all major providers
- `deploy-to-vercel.sh` - Automated deployment script
- `DEPLOY_NOW.md` - This quick start (you are here)

---

**Ready? Start here:**

```bash
cd /home/ubuntu/civil3d_training_course/nextjs-app
npx vercel login
npx vercel --prod --yes
npx vercel domains add classes.c3dinfo.com --prod
```

Then add DNS record at your provider. Done! 🎉
