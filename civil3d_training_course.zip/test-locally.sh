#!/bin/bash

# Local Testing Script for Civil 3D Training Course
# This script starts a local web server to preview the site

echo "🧪 Civil 3D Training Course - Local Testing"
echo "============================================"
echo ""
echo "📍 Starting local web server..."
echo ""

cd /home/ubuntu/civil3d_training_course/nextjs-app/out

echo "✅ Server running at: http://localhost:8000"
echo "📝 Note: This is localhost on the server, not your local machine"
echo "🛑 Press Ctrl+C to stop the server"
echo ""

python3 -m http.server 8000