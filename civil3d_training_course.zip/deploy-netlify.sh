#!/bin/bash

# Netlify Deployment Script for Civil 3D Training Course
# This script deploys the static site to Netlify

set -e

echo "🚀 Civil 3D Training Course - Netlify Deployment"
echo "================================================="
echo ""

# Check if netlify-cli is installed
if ! command -v netlify &> /dev/null; then
    echo "📦 Installing Netlify CLI..."
    npm install -g netlify-cli
fi

echo "📍 Navigating to output directory..."
cd /home/ubuntu/civil3d_training_course/nextjs-app/out

echo ""
echo "🔐 Please login to Netlify when prompted..."
echo ""

netlify login

echo ""
echo "🚢 Deploying to Netlify..."
echo ""

netlify deploy --prod --dir=.

echo ""
echo "✅ Deployment complete!"
echo "📋 Your site URL will be displayed above"
echo ""