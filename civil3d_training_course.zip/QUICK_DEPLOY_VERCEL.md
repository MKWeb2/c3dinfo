# Quick Deploy Guide - Vercel + classes.c3dinfo.com

**⚡ Fast Track Deployment - Read This First!**

---

## 🚀 3-Step Deployment

### Step 1: Deploy to Vercel (5 minutes)
```bash
cd /home/ubuntu/civil3d_training_course/nextjs-app/
npx vercel login     # Click email verification link
npx vercel --prod    # Deploy to production
```
**Result**: You'll get a URL like `https://civil3d-training-course.vercel.app`

---

### Step 2: Add Domain in Vercel (2 minutes)
1. Go to [Vercel Dashboard](https://vercel.com/dashboard)
2. Click your project → **Settings** → **Domains**
3. Enter: `classes.c3dinfo.com`
4. Click **Add**

---

### Step 3: Add DNS Record (5 minutes + wait for propagation)

**Add this to your DNS provider for c3dinfo.com:**

```
Type:  CNAME
Name:  classes
Value: cname.vercel-dns.com
TTL:   3600
```

**Common Providers:**
- **GoDaddy**: Domain Manager → DNS → Add Record
- **Namecheap**: Domain List → Manage → Advanced DNS → Add Record
- **Cloudflare**: DNS → Add Record (⚠️ Set to "DNS only", NOT proxied)

---

## ⏱️ Timeline

| What | Time |
|------|------|
| Active work | 15 minutes |
| DNS propagation | 1-4 hours |
| SSL certificate | Automatic |

---

## ✅ Verification

After DNS propagates (1-4 hours):

1. **Check DNS**: [https://dnschecker.org](https://dnschecker.org)
   - Enter: `classes.c3dinfo.com`
   - Should show: `cname.vercel-dns.com`

2. **Visit Site**: `https://classes.c3dinfo.com`
   - Should show: Your training course
   - Should have: 🔒 Padlock (HTTPS)

---

## 🆘 Troubleshooting

**Problem**: "Domain is not yet propagated"  
**Solution**: Wait 1-4 hours after adding DNS record

**Problem**: SSL not working  
**Solution**: Wait 15 minutes after DNS propagates

**Problem**: Vercel login fails  
**Solution**: Check your email for verification link

---

## 📖 Need More Help?

- **Full Guide**: See `CUSTOM_DOMAIN_SETUP.md` (20+ pages with screenshots)
- **Status**: See `VERCEL_DEPLOYMENT_STATUS.md` (detailed checklist)
- **Vercel Docs**: [https://vercel.com/docs](https://vercel.com/docs)

---

**That's it! Start with Step 1 above. 🚀**
