import SessionLayout from '../../components/SessionLayout'

export default function SessionTest() {
  return (
    <SessionLayout sessionNumber={99} title="Test Session">
      <div>Test Content</div>
    </SessionLayout>
  )
}
