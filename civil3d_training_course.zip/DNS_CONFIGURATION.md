# DNS Configuration for classes.c3dinfo.com

Quick reference guide for setting up your custom domain with Vercel.

---

## 🎯 Quick Setup (3 Steps)

### Step 1: Add Domain to Vercel
```bash
npx vercel domains add classes.c3dinfo.com --prod
```

### Step 2: Add DNS Record
Go to your DNS provider and add **ONE** of these records:

#### Option A: A Record (Recommended)
```
Type:  A
Name:  classes
Value: 76.76.21.21
TTL:   3600
```

#### Option B: CNAME Record
```
Type:  CNAME
Name:  classes
Value: cname.vercel-dns.com
TTL:   3600
```

### Step 3: Wait & Verify
- Wait 5-10 minutes for DNS propagation
- Visit: https://classes.c3dinfo.com
- SSL certificate will be automatically provisioned

---

## 🌐 DNS Provider Quick Links

### GoDaddy
1. Login: https://dcc.godaddy.com/manage/c3dinfo.com/dns
2. Click "Add" under Records
3. Select "A" record
4. Enter: Name=`classes`, Value=`76.76.21.21`
5. Save

### Cloudflare
1. Login: https://dash.cloudflare.com
2. Select domain: c3dinfo.com → DNS
3. Add record: Type=A, Name=`classes`, IPv4=`76.76.21.21`
4. ⚠️ **Important:** Set proxy to "DNS only" (gray cloud icon)
5. Save

### Namecheap
1. Login: https://ap.www.namecheap.com/domains/list/
2. Click "Manage" → Advanced DNS
3. Add New Record: Type=A, Host=`classes`, Value=`76.76.21.21`
4. Save

### Google Domains / Squarespace
1. Login to your domain dashboard
2. Go to DNS settings
3. Add custom record: Type=A, Name=`classes`, Data=`76.76.21.21`
4. Save

### AWS Route 53
1. Login: https://console.aws.amazon.com/route53/
2. Hosted zones → c3dinfo.com
3. Create record: Name=`classes.c3dinfo.com`, Type=A, Value=`76.76.21.21`
4. Create

---

## ✅ Verification Commands

### Check DNS Propagation
```bash
# Check if DNS is resolving
nslookup classes.c3dinfo.com

# Should show: 76.76.21.21
```

### Check Domain Status in Vercel
```bash
# Inspect domain configuration
npx vercel domains inspect classes.c3dinfo.com

# List all domains
npx vercel domains ls
```

### Test Website
```bash
# Test if site is accessible
curl -I https://classes.c3dinfo.com

# Should return: HTTP/2 200
```

---

## ⏱️ Timeline

- **Immediate:** DNS record added to provider
- **5-10 minutes:** DNS propagation starts
- **15-30 minutes:** Full global propagation
- **1-24 hours:** SSL certificate automatic provisioning
- **After SSL:** Site fully live with HTTPS

---

## 🔧 Troubleshooting

### "Domain not found" error
```bash
# Remove and re-add domain
npx vercel domains rm classes.c3dinfo.com
npx vercel domains add classes.c3dinfo.com --prod
```

### DNS not resolving
1. Clear local DNS cache:
   ```bash
   # On Linux/Mac
   sudo systemd-resolve --flush-caches
   # Or
   sudo dscacheutil -flushcache
   ```
2. Check from external tool: https://dnschecker.org
3. Wait up to 48 hours for full propagation

### SSL certificate not provisioning
1. Verify DNS points to Vercel: `nslookup classes.c3dinfo.com`
2. Check for CAA records blocking Let's Encrypt
3. Wait up to 24 hours
4. Contact Vercel support if still pending

### "Mixed content" warnings
- Ensure all resources use HTTPS
- Update any hardcoded HTTP URLs to HTTPS

---

## 📊 DNS Record Reference

### What Each Record Does:

**A Record:**
- Points domain directly to Vercel's IP address
- Faster initial connection
- More reliable for most DNS providers

**CNAME Record:**
- Points domain to Vercel's hostname
- More flexible if Vercel changes IPs
- May not work on apex domains (root domain)

### Why classes.c3dinfo.com?
- `c3dinfo.com` = apex/root domain
- `classes` = subdomain
- Full domain: `classes.c3dinfo.com`

---

## 🎓 Testing Checklist

After DNS is configured:

- [ ] Homepage loads: https://classes.c3dinfo.com
- [ ] SSL certificate valid (padlock icon)
- [ ] Session pages work: https://classes.c3dinfo.com/session/1
- [ ] All 12 sessions accessible
- [ ] Integration pages work
- [ ] Mobile responsive
- [ ] Fast load times (< 2 seconds)

---

## 📞 Need Help?

### Vercel Support
- Documentation: https://vercel.com/docs/custom-domains
- Community: https://github.com/vercel/vercel/discussions
- Status: https://www.vercel-status.com

### DNS Help
- Check propagation: https://dnschecker.org
- DNS basics: https://www.cloudflare.com/learning/dns/what-is-dns/

---

**Quick Summary:**
1. `npx vercel domains add classes.c3dinfo.com --prod`
2. Add A record: `classes` → `76.76.21.21` at your DNS provider
3. Wait 10-30 minutes
4. Visit: https://classes.c3dinfo.com

✅ Done!
